Success = 0
PipeClosed = 1
ReadCorrupt = 2
